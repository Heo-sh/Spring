package context;

import org.springframework.context.annotation.Configuration;

//DAO에 관련된 객체만 관리할 설정파일
@Configuration
public class Context_3_dao {
}
